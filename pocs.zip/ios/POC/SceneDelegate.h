//
//  SceneDelegate.h
//  POC
//
//  Created by henry on 11/2/19.
//  Copyright © 2019 Bontech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

